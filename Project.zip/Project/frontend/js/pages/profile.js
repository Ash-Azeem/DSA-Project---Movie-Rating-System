document.addEventListener('DOMContentLoaded', async () => {
  // Initialize services
  const authService = window.authService;
  const userService = window.userService;

  // Initialize authentication
  await authService.init();

  // Check if user is logged in
  if (!authService.isLoggedIn()) {
    window.location.href = 'login.html';
    return;
  }

  // Load profile data
  await loadProfileData();

  // Setup event listeners
  setupEventListeners();
});

// Load profile data
async function loadProfileData() {
  try {
    showLoadingSpinner();
    
    const user = authService.getCurrentUser();
    
    // Update profile header
    updateProfileHeader(user);
    
    // Load user's ratings, reviews, and watchlist
    await Promise.all([
      loadUserRatings(),
      loadUserReviews(),
      loadUserWatchlist()
    ]);
  } catch (error) {
    console.error('Error loading profile data:', error);
  } finally {
    hideLoadingSpinner();
  }
}

// Update profile header
function updateProfileHeader(user) {
  const profileImage = document.getElementById('profile-image');
  const profileName = document.getElementById('profile-name');
  const profileUsername = document.getElementById('profile-username');
  const profileBio = document.getElementById('profile-bio');
  const totalRatings = document.getElementById('total-ratings');
  const totalReviews = document.getElementById('total-reviews');
  const watchlistCount = document.getElementById('watchlist-count');

  if (profileImage) {
    profileImage.src = user.profile_image_url || 'https://via.placeholder.com/150x150';
  }
  
  if (profileName) {
    profileName.textContent = user.first_name || user.last_name 
      ? `${user.first_name} ${user.last_name}` 
      : user.username;
  }
  
  if (profileUsername) {
    profileUsername.textContent = `@${user.username}`;
  }
  
  if (profileBio) {
    profileBio.textContent = user.bio || 'No bio available';
  }
}

// Load user ratings
async function loadUserRatings(page = 1) {
  try {
    const response = await userService.getUserRatings({ page, limit: 12 });
    
    if (response.success) {
      userService.renderUserRatings(response.data.ratings, 'user-ratings');
      window.Pagination.create(
        response.data.pagination.page,
        response.data.pagination.pages,
        'ratings-pagination',
        (newPage) => loadUserRatings(newPage)
      );
    }
  } catch (error) {
    console.error('Error loading user ratings:', error);
  }
}

// Load user reviews
async function loadUserReviews(page = 1) {
  try {
    const response = await userService.getUserReviews({ page, limit: 10 });
    
    if (response.success) {
      userService.renderUserReviews(response.data.reviews, 'user-reviews');
      window.Pagination.create(
        response.data.pagination.page,
        response.data.pagination.pages,
        'reviews-pagination',
        (newPage) => loadUserReviews(newPage)
      );
    }
  } catch (error) {
    console.error('Error loading user reviews:', error);
  }
}

// Load user watchlist
async function loadUserWatchlist(page = 1) {
  try {
    const response = await userService.getUserWatchlist({ page, limit: 12 });
    
    if (response.success) {
      window.MovieCard.renderList(response.data.watchlist.map(item => ({
        ...item.Movie,
        isInWatchlist: true
      })), 'user-watchlist');
      
      window.Pagination.create(
        response.data.pagination.page,
        response.data.pagination.pages,
        'watchlist-pagination',
        (newPage) => loadUserWatchlist(newPage)
      );
    }
  } catch (error) {
    console.error('Error loading user watchlist:', error);
  }
}

// Setup event listeners
function setupEventListeners() {
  setupTabs();
  setupSettingsForm();
  setupPasswordForm();
  setupAvatarUpload();
  setupDeleteAccount();
}

// Setup tabs
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.dataset.tab;
      
      // Update active states
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));
      
      button.classList.add('active');
      document.getElementById(`${tabName}-tab`).classList.add('active');
    });
  });
}

// Setup settings form
function setupSettingsForm() {
  const settingsForm = document.getElementById('settings-form');
  if (!settingsForm) return;

  const user = window.authService.getCurrentUser();
  
  // Pre-fill form
  const firstNameInput = document.getElementById('settings-first-name');
  const lastNameInput = document.getElementById('settings-last-name');
  const bioInput = document.getElementById('settings-bio');
  const emailInput = document.getElementById('settings-email');

  if (firstNameInput) firstNameInput.value = user.first_name || '';
  if (lastNameInput) lastNameInput.value = user.last_name || '';
  if (bioInput) bioInput.value = user.bio || '';
  if (emailInput) emailInput.value = user.email || '';

  settingsForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(settingsForm);
    const profileData = {
      first_name: formData.get('first_name'),
      last_name: formData.get('last_name'),
      bio: formData.get('bio')
    };

    try {
      await userService.updateProfile(profileData);
      updateProfileHeader({ ...user, ...profileData });
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  });
}

// Setup password form
function setupPasswordForm() {
  const passwordForm = document.getElementById('password-form');
  if (!passwordForm) return;

  passwordForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(passwordForm);
    const currentPassword = formData.get('current_password');
    const newPassword = formData.get('new_password');
    const confirmNewPassword = formData.get('confirm_new_password');

    // Validate passwords match
    if (newPassword !== confirmNewPassword) {
      window.notificationService.error('New passwords do not match');
      return;
    }

    const passwordData = {
      current_password: currentPassword,
      new_password: newPassword
    };

    try {
      await userService.changePassword(passwordData);
      passwordForm.reset();
    } catch (error) {
      console.error('Error changing password:', error);
    }
  });
}

// Setup avatar upload
function setupAvatarUpload() {
  const changeAvatarBtn = document.getElementById('change-avatar-btn');
  const avatarInput = document.getElementById('avatar-input');
  
  if (!changeAvatarBtn || !avatarInput) return;

  changeAvatarBtn.addEventListener('click', () => {
    avatarInput.click();
  });

  avatarInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      window.notificationService.error('Please select an image file');
      return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      window.notificationService.error('Image size must be less than 5MB');
      return;
    }

    try {
      showLoadingSpinner();
      await userService.uploadProfilePicture(file);
      
      // Update profile image
      const profileImage = document.getElementById('profile-image');
      if (profileImage) {
        profileImage.src = URL.createObjectURL(file);
      }
    } catch (error) {
      console.error('Error uploading profile picture:', error);
    } finally {
      hideLoadingSpinner();
    }
  });
}

// Setup delete account
function setupDeleteAccount() {
  const deleteAccountBtn = document.getElementById('delete-account-btn');
  if (!deleteAccountBtn) return;

  deleteAccountBtn.addEventListener('click', async () => {
    if (!confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      return;
    }

    if (!confirm('This will permanently delete all your data including ratings, reviews, and watchlist. Are you absolutely sure?')) {
      return;
    }

    try {
      await userService.deleteAccount();
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  });
}

// Show loading spinner
function showLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'block';
  }
}

// Hide loading spinner
function hideLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'none';
  }
}