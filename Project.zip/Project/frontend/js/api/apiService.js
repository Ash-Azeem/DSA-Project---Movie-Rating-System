class ApiService {
  constructor() {
    this.baseURL = 'http://localhost:5000/api';
    this.token = localStorage.getItem('token');
  }

  // Set authentication token
  setToken(token) {
    this.token = token;
    localStorage.setItem('token', token);
  }

  // Clear authentication token
  clearToken() {
    this.token = null;
    localStorage.removeItem('token');
  }

  // Generic request method
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(this.token && { Authorization: `Bearer ${this.token}` }),
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Something went wrong');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Authentication methods
  async register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }

  async login(credentials) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
    
    if (data.success) {
      this.setToken(data.data.token);
    }
    
    return data;
  }

  async getCurrentUser() {
    return this.request('/auth/me');
  }

  async updateProfile(profileData) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });
  }

  async changePassword(passwordData) {
    return this.request('/auth/password', {
      method: 'PUT',
      body: JSON.stringify(passwordData)
    });
  }

  async logout() {
    const data = await this.request('/auth/logout', {
      method: 'POST'
    });
    
    if (data.success) {
      this.clearToken();
    }
    
    return data;
  }

  // Movie methods
  async getMovies(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/movies?${queryString}`);
  }

  async getMovieById(id) {
    return this.request(`/movies/${id}`);
  }

  async getTopRatedMovies(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/movies/top-rated?${queryString}`);
  }

  async getNewReleases(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/movies/new-releases?${queryString}`);
  }

  async getMoviesByGenre(genre, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/movies/genre/${genre}?${queryString}`);
  }

  async getRecommendations(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/movies/recommendations?${queryString}`);
  }

  async searchMovies(query, params = {}) {
    const queryString = new URLSearchParams({ ...params, q: query }).toString();
    return this.request(`/movies/search?${queryString}`);
  }

  async rateMovie(movieId, rating) {
    return this.request(`/movies/${movieId}/rate`, {
      method: 'POST',
      body: JSON.stringify({ rating })
    });
  }

  // Review methods
  async createReview(reviewData) {
    return this.request('/reviews', {
      method: 'POST',
      body: JSON.stringify(reviewData)
    });
  }

  async updateReview(reviewId, reviewData) {
    return this.request(`/reviews/${reviewId}`, {
      method: 'PUT',
      body: JSON.stringify(reviewData)
    });
  }

  async deleteReview(reviewId) {
    return this.request(`/reviews/${reviewId}`, {
      method: 'DELETE'
    });
  }

  async getMovieReviews(movieId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/reviews/movie/${movieId}?${queryString}`);
  }

  // Watchlist methods
  async addToWatchlist(movieId) {
    return this.request('/watchlists', {
      method: 'POST',
      body: JSON.stringify({ movie_id: movieId })
    });
  }

  async removeFromWatchlist(movieId) {
    return this.request(`/watchlists/${movieId}`, {
      method: 'DELETE'
    });
  }

  async getWatchlist(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/watchlists?${queryString}`);
  }

  async checkInWatchlist(movieId) {
    return this.request(`/watchlists/check/${movieId}`);
  }

  // User methods
  async getUserProfile(userId) {
    return this.request(`/users/${userId}`);
  }

  async getUserRatings(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/users/ratings?${queryString}`);
  }

  async getUserReviews(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/users/reviews?${queryString}`);
  }

  async getUserWatchlist(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/users/watchlist?${queryString}`);
  }

  async deleteAccount() {
    return this.request('/users/account', {
      method: 'DELETE'
    });
  }

  // Statistics methods
  async getDatabaseStats() {
    return this.request('/stats/database');
  }

  async getYearsWithMultipleReleases() {
    return this.request('/stats/years-with-multiple-releases');
  }

  async getTopDecadesByRuntime() {
    return this.request('/stats/top-decades-by-runtime');
  }

  async getGenreDistribution() {
    return this.request('/stats/genre-distribution');
  }

  async getRatingDistribution() {
    return this.request('/stats/rating-distribution');
  }

  async getUserActivityStats() {
    return this.request('/stats/user-activity');
  }
}

// Create a singleton instance
const apiService = new ApiService();

// Export the instance
window.apiService = apiService;