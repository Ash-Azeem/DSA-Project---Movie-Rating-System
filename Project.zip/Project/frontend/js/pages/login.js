document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const authService = window.authService;
  const notificationService = window.notificationService;

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(loginForm);
    const credentials = {
      email: formData.get('email'),
      password: formData.get('password')
    };

    try {
      const result = await authService.login(credentials);
      
      if (result.success) {
        notificationService.success('Login successful! Redirecting...');
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1500);
      } else {
        notificationService.error(result.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      notificationService.error('An error occurred during login');
    }
  });
});