document.addEventListener('DOMContentLoaded', async () => {
  // Initialize services
  const authService = window.authService;
  const movieService = window.movieService;

  // Initialize authentication
  await authService.init();

  // Get search parameters from URL
  const urlParams = new URLSearchParams(window.location.search);
  const searchQuery = urlParams.get('q') || '';
  const genre = urlParams.get('genre') || '';
  const sort = urlParams.get('sort') || 'title-asc';

  // Setup search page
  setupSearchPage(searchQuery, genre, sort);

  // Load search results
  await loadSearchResults(1);
});

// Setup search page
function setupSearchPage(query, genre, sort) {
  // Update search query display
  const searchQueryText = document.getElementById('search-query-text');
  if (searchQueryText) {
    searchQueryText.textContent = query || genre || 'All Movies';
  }

  // Setup filters
  setupFilters(sort);

  // Setup search input
  setupSearchInput();
}

// Setup filters
function setupFilters(defaultSort) {
  const sortSelect = document.getElementById('sort-select');
  const genreFilter = document.getElementById('genre-filter');
  const yearFilter = document.getElementById('year-filter');

  // Set default sort
  if (sortSelect && defaultSort) {
    sortSelect.value = defaultSort;
  }

  // Load genres
  if (genreFilter) {
    const genres = [
      'Action', 'Adventure', 'Animation', 'Comedy', 'Crime',
      'Documentary', 'Drama', 'Family', 'Fantasy', 'History',
      'Horror', 'Music', 'Mystery', 'Romance', 'Science Fiction',
      'TV Movie', 'Thriller', 'War', 'Western'
    ];

    genres.forEach(genre => {
      const option = document.createElement('option');
      option.value = genre.toLowerCase().replace(' ', '-');
      option.textContent = genre;
      genreFilter.appendChild(option);
    });
  }

  // Load years
  if (yearFilter) {
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 1900; year--) {
      const option = document.createElement('option');
      option.value = year;
      option.textContent = year;
      yearFilter.appendChild(option);
    }
  }

  // Add event listeners
  [sortSelect, genreFilter, yearFilter].forEach(select => {
    if (select) {
      select.addEventListener('change', () => {
        loadSearchResults(1);
      });
    }
  });
}

// Setup search input
function setupSearchInput() {
  // Add search input to header if not exists
  let searchContainer = document.querySelector('.search-container');
  if (!searchContainer) {
    const header = document.querySelector('.header-container');
    if (header) {
      searchContainer = document.createElement('div');
      searchContainer.className = 'search-container';
      searchContainer.style.marginLeft = 'auto';
      searchContainer.style.width = '300px';
      searchContainer.innerHTML = `
        <input type="text" id="page-search-input" placeholder="Search movies...">
        <button id="page-search-btn"><i class="fas fa-search"></i></button>
      `;
      header.appendChild(searchContainer);
    }
  }

  const searchInput = document.getElementById('page-search-input');
  const searchBtn = document.getElementById('page-search-btn');

  if (searchInput && searchBtn) {
    searchBtn.addEventListener('click', () => {
      const query = searchInput.value.trim();
      if (query) {
        const url = new URL(window.location);
        url.searchParams.set('q', query);
        url.searchParams.delete('genre');
        window.location.href = url.toString();
      }
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const query = searchInput.value.trim();
        if (query) {
          const url = new URL(window.location);
          url.searchParams.set('q', query);
          url.searchParams.delete('genre');
          window.location.href = url.toString();
        }
      }
    });
  }
}

// Load search results
async function loadSearchResults(page = 1) {
  try {
    showLoadingSpinner();

    // Get search parameters
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q');
    const genre = urlParams.get('genre');
    const sortSelect = document.getElementById('sort-select');
    const genreFilter = document.getElementById('genre-filter');
    const yearFilter = document.getElementById('year-filter');

    // Build search parameters
    const params = { page };
    
    if (searchQuery) {
      params.q = searchQuery;
    }
    
    if (genre) {
      params.genre = genre;
    } else if (genreFilter && genreFilter.value) {
      params.genre = genreFilter.value;
    }
    
    if (sortSelect && sortSelect.value) {
      params.sort = sortSelect.value;
    }
    
    if (yearFilter && yearFilter.value) {
      params.year = yearFilter.value;
    }

    let response;
    
    if (searchQuery) {
      response = await movieService.searchMovies(searchQuery, params);
    } else if (genre || (genreFilter && genreFilter.value)) {
      const selectedGenre = genre || genreFilter.value;
      response = await movieService.getMoviesByGenre(selectedGenre, params);
    } else {
      response = await movieService.getMovies(params);
    }

    if (response.success) {
      displaySearchResults(response.data);
    } else {
      throw new Error(response.message || 'Search failed');
    }
  } catch (error) {
    console.error('Error loading search results:', error);
    displayError(error.message);
  } finally {
    hideLoadingSpinner();
  }
}

// Display search results
function displaySearchResults(data) {
  const resultsContainer = document.getElementById('search-results');
  const paginationContainer = document.getElementById('search-pagination');
  const noResultsContainer = document.getElementById('no-results');
  const resultsInfo = document.getElementById('search-results-info');

  // Show/hide appropriate containers
  if (data.movies && data.movies.length > 0) {
    if (resultsContainer) resultsContainer.style.display = 'grid';
    if (noResultsContainer) noResultsContainer.style.display = 'none';
    
    // Render movies
    window.MovieCard.renderList(data.movies, 'search-results');
    
    // Render pagination
    if (paginationContainer && data.pagination.pages > 1) {
      window.Pagination.create(
        data.pagination.page,
        data.pagination.pages,
        'search-pagination',
        (newPage) => loadSearchResults(newPage)
      );
    } else if (paginationContainer) {
      paginationContainer.innerHTML = '';
    }
    
    // Update results info
    if (resultsInfo) {
      resultsInfo.innerHTML = `
        <span>Showing ${((data.pagination.page - 1) * data.pagination.limit) + 1} to ${Math.min(data.pagination.page * data.pagination.limit, data.pagination.total)} of ${data.pagination.total} results</span>
      `;
    }
  } else {
    if (resultsContainer) resultsContainer.style.display = 'none';
    if (paginationContainer) paginationContainer.innerHTML = '';
    if (noResultsContainer) noResultsContainer.style.display = 'block';
    if (resultsInfo) resultsInfo.innerHTML = '<span>No results found</span>';
  }
}

// Display error
function displayError(message) {
  const resultsContainer = document.getElementById('search-results');
  const paginationContainer = document.getElementById('search-pagination');
  const noResultsContainer = document.getElementById('no-results');
  const resultsInfo = document.getElementById('search-results-info');

  if (resultsContainer) resultsContainer.style.display = 'none';
  if (paginationContainer) paginationContainer.innerHTML = '';
  if (noResultsContainer) {
    noResultsContainer.style.display = 'block';
    noResultsContainer.innerHTML = `
      <i class="fas fa-exclamation-triangle"></i>
      <h2>Error</h2>
      <p>${message}</p>
    `;
  }
  if (resultsInfo) resultsInfo.innerHTML = '<span>Error occurred</span>';
}

// Show loading spinner
function showLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'block';
  }
}

// Hide loading spinner
function hideLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'none';
  }
}