const { body, param, query } = require('express-validator');

// User validators
exports.validateUserRegistration = [
  body('username')
    .isLength({ min: 3, max: 50 })
    .withMessage('Username must be between 3 and 50 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),
  body('first_name')
    .optional()
    .isLength({ min: 1, max: 50 })
    .withMessage('First name must be between 1 and 50 characters'),
  body('last_name')
    .optional()
    .isLength({ min: 1, max: 50 })
    .withMessage('Last name must be between 1 and 50 characters'),
  body('date_of_birth')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid date of birth')
];

exports.validateUserLogin = [
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

// Movie validators
exports.validateMovieId = [
  param('id')
    .isInt({ min: 1 })
    .withMessage('Movie ID must be a positive integer')
];

exports.validateMovieRating = [
  body('rating')
    .isFloat({ min: 0, max: 10 })
    .withMessage('Rating must be between 0 and 10')
];

// Review validators
exports.validateReviewCreation = [
  body('movie_id')
    .isInt({ min: 1 })
    .withMessage('Movie ID must be a positive integer'),
  body('title')
    .optional()
    .isLength({ max: 255 })
    .withMessage('Review title must be less than 255 characters'),
  body('content')
    .notEmpty()
    .withMessage('Review content is required')
    .isLength({ min: 10, max: 5000 })
    .withMessage('Review content must be between 10 and 5000 characters'),
  body('is_spoiler')
    .optional()
    .isBoolean()
    .withMessage('is_spoiler must be a boolean')
];

// Pagination validators
exports.validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
];

module.exports = {
  validateUserRegistration: exports.validateUserRegistration,
  validateUserLogin: exports.validateUserLogin,
  validateMovieId: exports.validateMovieId,
  validateMovieRating: exports.validateMovieRating,
  validateReviewCreation: exports.validateReviewCreation,
  validatePagination: exports.validatePagination
};