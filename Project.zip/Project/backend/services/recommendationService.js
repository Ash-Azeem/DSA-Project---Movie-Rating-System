const { Movie, Genre, Rating, User } = require('../models');
const { Op } = require('sequelize');
const sequelize = require('../config/database');

class RecommendationService {
  // Get personalized recommendations for a user
  async getPersonalizedRecommendations(userId, limit = 10) {
    try {
      // Get user's rating history
      const userRatings = await Rating.findAll({
        where: { user_id: userId },
        include: [{ model: Movie, include: [Genre] }]
      });

      if (userRatings.length === 0) {
        // If user hasn't rated anything, return popular movies
        return this.getPopularMovies(limit);
      }

      // Extract user's preferred genres based on highly rated movies (4+ stars)
      const genrePreferences = this.extractGenrePreferences(userRatings);
      
      // Get similar users based on rating patterns
      const similarUsers = await this.findSimilarUsers(userId, userRatings);
      
      // Get movies liked by similar users that the current user hasn't watched
      const collaborativeRecommendations = await this.getCollaborativeRecommendations(
        userId, 
        similarUsers, 
        limit / 2
      );
      
      // Get movies from user's preferred genres that they haven't watched
      const contentBasedRecommendations = await this.getContentBasedRecommendations(
        userId, 
        genrePreferences, 
        limit / 2
      );
      
      // Combine and rank recommendations
      const recommendations = this.combineRecommendations(
        collaborativeRecommendations, 
        contentBasedRecommendations
      );
      
      return recommendations.slice(0, limit);
    } catch (error) {
      console.error('Error getting personalized recommendations:', error);
      return this.getPopularMovies(limit);
    }
  }

  // Extract user's preferred genres based on ratings
  extractGenrePreferences(userRatings) {
    const genreScores = {};
    
    userRatings.forEach(rating => {
      const score = parseFloat(rating.rating);
      if (score >= 4) { // Only consider highly rated movies
        rating.Movie.Genres.forEach(genre => {
          if (!genreScores[genre.name]) {
            genreScores[genre.name] = 0;
          }
          genreScores[genre.name] += score;
        });
      }
    });
    
    // Sort genres by score
    return Object.entries(genreScores)
      .sort((a, b) => b[1] - a[1])
      .map(([name, score]) => ({ name, score }));
  }

  // Find users with similar taste
  async findSimilarUsers(userId, userRatings, limit = 20) {
    try {
      // Create a map of movie_id -> rating for the current user
      const userMovieRatings = {};
      userRatings.forEach(rating => {
        userMovieRatings[rating.movie_id] = parseFloat(rating.rating);
      });
      
      // Get all users who have rated at least 3 of the same movies
      const similarUsers = await sequelize.query(`
        SELECT r.user_id, r.movie_id, r.rating
        FROM ratings r
        WHERE r.movie_id IN (${Object.keys(userMovieRatings).join(',')})
          AND r.user_id != ?
        ORDER BY r.user_id
      `, {
        replacements: [userId],
        type: sequelize.QueryTypes.SELECT
      });
      
      // Group ratings by user
      const ratingsByUser = {};
      similarUsers.forEach(rating => {
        if (!ratingsByUser[rating.user_id]) {
          ratingsByUser[rating.user_id] = [];
        }
        ratingsByUser[rating.user_id].push({
          movie_id: rating.movie_id,
          rating: parseFloat(rating.rating)
        });
      });
      
      // Calculate similarity scores
      const userSimilarities = [];
      Object.entries(ratingsByUser).forEach(([otherUserId, otherRatings]) => {
        if (otherRatings.length >= 3) { // Only consider users with at least 3 overlapping ratings
          const similarity = this.calculateSimilarity(userMovieRatings, otherRatings);
          if (similarity > 0.3) { // Only consider users with similarity > 0.3
            userSimilarities.push({
              user_id: parseInt(otherUserId),
              similarity
            });
          }
        }
      });
      
      // Sort by similarity and return top users
      return userSimilarities
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, limit);
    } catch (error) {
      console.error('Error finding similar users:', error);
      return [];
    }
  }

  // Calculate similarity between two users using Pearson correlation
  calculateSimilarity(user1Ratings, user2Ratings) {
    // Create a map of movie_id -> rating for user2
    const user2Map = {};
    user2Ratings.forEach(rating => {
      user2Map[rating.movie_id] = rating.rating;
    });
    
    // Find common movies
    const commonMovies = Object.keys(user1Ratings).filter(
      movieId => movieId in user2Map
    );
    
    if (commonMovies.length < 3) return 0;
    
    // Calculate Pearson correlation
    const sum1 = commonMovies.reduce((sum, movieId) => sum + user1Ratings[movieId], 0);
    const sum2 = commonMovies.reduce((sum, movieId) => sum + user2Map[movieId], 0);
    
    const sum1Sq = commonMovies.reduce(
      (sum, movieId) => sum + Math.pow(user1Ratings[movieId], 2), 0
    );
    const sum2Sq = commonMovies.reduce(
      (sum, movieId) => sum + Math.pow(user2Map[movieId], 2), 0
    );
    
    const pSum = commonMovies.reduce(
      (sum, movieId) => sum + user1Ratings[movieId] * user2Map[movieId], 0
    );
    
    const num = pSum - (sum1 * sum2 / commonMovies.length);
    const den = Math.sqrt(
      (sum1Sq - Math.pow(sum1, 2) / commonMovies.length) *
      (sum2Sq - Math.pow(sum2, 2) / commonMovies.length)
    );
    
    if (den === 0) return 0;
    
    return num / den;
  }

  // Get collaborative filtering recommendations
  async getCollaborativeRecommendations(userId, similarUsers, limit) {
    try {
      if (similarUsers.length === 0) return [];
      
      // Get movies rated by similar users that the current user hasn't rated
      const similarUserIds = similarUsers.map(u => u.user_id);
      
      const recommendations = await sequelize.query(`
        SELECT m.movie_id, m.title, m.poster_path, m.release_date,
               AVG(r.rating) as avgRating, COUNT(r.rating) as ratingCount,
               SUM(r.rating * u.similarity) / SUM(u.similarity) as weightedRating
        FROM movies m
        JOIN ratings r ON m.movie_id = r.movie_id
        JOIN (
          ${similarUsers.map(u => `SELECT ${u.user_id} as user_id, ${u.similarity} as similarity`).join(' UNION ALL ')}
        ) u ON r.user_id = u.user_id
        WHERE m.movie_id NOT IN (
          SELECT movie_id FROM ratings WHERE user_id = ?
        )
        GROUP BY m.movie_id
        HAVING ratingCount >= 2
        ORDER BY weightedRating DESC, ratingCount DESC
        LIMIT ?
      `, {
        replacements: [userId, limit],
        type: sequelize.QueryTypes.SELECT
      });
      
      return recommendations.map(movie => ({
        ...movie,
        avgRating: parseFloat(movie.avgRating).toFixed(1),
        weightedRating: parseFloat(movie.weightedRating).toFixed(1),
        recommendationType: 'collaborative'
      }));
    } catch (error) {
      console.error('Error getting collaborative recommendations:', error);
      return [];
    }
  }

  // Get content-based recommendations
  async getContentBasedRecommendations(userId, genrePreferences, limit) {
    try {
      if (genrePreferences.length === 0) return [];
      
      // Get top preferred genres
      const topGenres = genrePreferences.slice(0, 3).map(g => g.name);
      
      // Get movies from these genres that the user hasn't rated
      const recommendations = await sequelize.query(`
        SELECT DISTINCT m.movie_id, m.title, m.poster_path, m.release_date,
               AVG(r.rating) as avgRating, COUNT(r.rating) as ratingCount
        FROM movies m
        JOIN movie_genres mg ON m.movie_id = mg.movie_id
        JOIN genres g ON mg.genre_id = g.genre_id
        LEFT JOIN ratings r ON m.movie_id = r.movie_id
        WHERE g.name IN (${topGenres.map(() => '?').join(',')})
          AND m.movie_id NOT IN (
            SELECT movie_id FROM ratings WHERE user_id = ?
          )
        GROUP BY m.movie_id
        HAVING ratingCount >= 2
        ORDER BY avgRating DESC, ratingCount DESC
        LIMIT ?
      `, {
        replacements: [...topGenres, userId, limit],
        type: sequelize.QueryTypes.SELECT
      });
      
      return recommendations.map(movie => ({
        ...movie,
        avgRating: parseFloat(movie.avgRating).toFixed(1),
        recommendationType: 'content-based'
      }));
    } catch (error) {
      console.error('Error getting content-based recommendations:', error);
      return [];
    }
  }

  // Combine and rank recommendations from different sources
  combineRecommendations(collaborative, contentBased) {
    // Normalize scores
    const maxCollaborative = collaborative.length > 0 
      ? Math.max(...collaborative.map(m => parseFloat(m.weightedRating)))
      : 1;
    
    const maxContentBased = contentBased.length > 0
      ? Math.max(...contentBased.map(m => parseFloat(m.avgRating)))
      : 1;
    
    // Normalize and combine
    const normalizedCollaborative = collaborative.map(movie => ({
      ...movie,
      normalizedScore: (parseFloat(movie.weightedRating) / maxCollaborative) * 0.6
    }));
    
    const normalizedContentBased = contentBased.map(movie => ({
      ...movie,
      normalizedScore: (parseFloat(movie.avgRating) / maxContentBased) * 0.4
    }));
    
    // Combine and sort by normalized score
    return [...normalizedCollaborative, ...normalizedContentBased]
      .sort((a, b) => b.normalizedScore - a.normalizedScore);
  }

  // Get popular movies as fallback
  async getPopularMovies(limit = 10) {
    try {
      const popularMovies = await sequelize.query(`
        SELECT m.movie_id, m.title, m.poster_path, m.release_date,
               AVG(r.rating) as avgRating, COUNT(r.rating) as ratingCount
        FROM movies m
        LEFT JOIN ratings r ON m.movie_id = r.movie_id
        GROUP BY m.movie_id
        HAVING ratingCount >= 10
        ORDER BY avgRating DESC, ratingCount DESC
        LIMIT ?
      `, {
        replacements: [limit],
        type: sequelize.QueryTypes.SELECT
      });
      
      return popularMovies.map(movie => ({
        ...movie,
        avgRating: parseFloat(movie.avgRating).toFixed(1),
        recommendationType: 'popular'
      }));
    } catch (error) {
      console.error('Error getting popular movies:', error);
      return [];
    }
  }

  // Get similar movies to a specific movie
  async getSimilarMovies(movieId, limit = 10) {
    try {
      // Get the movie's genres
      const movieGenres = await sequelize.query(`
        SELECT g.genre_id, g.name
        FROM genres g
        JOIN movie_genres mg ON g.genre_id = mg.genre_id
        WHERE mg.movie_id = ?
      `, {
        replacements: [movieId],
        type: sequelize.QueryTypes.SELECT
      });
      
      if (movieGenres.length === 0) {
        return this.getPopularMovies(limit);
      }
      
      const genreIds = movieGenres.map(g => g.genre_id);
      
      // Get movies with similar genres
      const similarMovies = await sequelize.query(`
        SELECT m.movie_id, m.title, m.poster_path, m.release_date,
               AVG(r.rating) as avgRating, COUNT(r.rating) as ratingCount,
               COUNT(mg.movie_id) as genreMatchCount
        FROM movies m
        JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN ratings r ON m.movie_id = r.movie_id
        WHERE mg.genre_id IN (${genreIds.map(() => '?').join(',')})
          AND m.movie_id != ?
        GROUP BY m.movie_id
        HAVING genreMatchCount > 0
        ORDER BY genreMatchCount DESC, avgRating DESC
        LIMIT ?
      `, {
        replacements: [...genreIds, movieId, limit],
        type: sequelize.QueryTypes.SELECT
      });
      
      return similarMovies.map(movie => ({
        ...movie,
        avgRating: parseFloat(movie.avgRating).toFixed(1)
      }));
    } catch (error) {
      console.error('Error getting similar movies:', error);
      return this.getPopularMovies(limit);
    }
  }
}

module.exports = new RecommendationService();