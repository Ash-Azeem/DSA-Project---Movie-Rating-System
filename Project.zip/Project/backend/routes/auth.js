const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { auth } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    // Create unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  // Accept images only
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed'), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

// Validation middleware
const validateRegister = (req, res, next) => {
  const { username, email, password, first_name, last_name, date_of_birth } = req.body;
  
  // Basic validation
  if (!username || username.length < 3 || username.length > 50) {
    return res.status(400).json({
      success: false,
      message: 'Username must be between 3 and 50 characters'
    });
  }
  
  if (!email || !email.includes('@')) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid email'
    });
  }
  
  if (!password || password.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'Password must be at least 6 characters'
    });
  }
  
  next();
};

const validateLogin = (req, res, next) => {
  const { email, password } = req.body;
  
  if (!email || !email.includes('@')) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid email'
    });
  }
  
  if (!password) {
    return res.status(400).json({
      success: false,
      message: 'Password is required'
    });
  }
  
  next();
};

const validateUpdateProfile = (req, res, next) => {
  const { first_name, last_name, bio } = req.body;
  
  if (first_name && (first_name.length < 1 || first_name.length > 50)) {
    return res.status(400).json({
      success: false,
      message: 'First name must be between 1 and 50 characters'
    });
  }
  
  if (last_name && (last_name.length < 1 || last_name.length > 50)) {
    return res.status(400).json({
      success: false,
      message: 'Last name must be between 1 and 50 characters'
    });
  }
  
  if (bio && bio.length > 1000) {
    return res.status(400).json({
      success: false,
      message: 'Bio must be less than 1000 characters'
    });
  }
  
  next();
};

const validateChangePassword = (req, res, next) => {
  const { current_password, new_password } = req.body;
  
  if (!current_password) {
    return res.status(400).json({
      success: false,
      message: 'Current password is required'
    });
  }
  
  if (!new_password || new_password.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'New password must be at least 6 characters'
    });
  }
  
  next();
};

// Public routes
router.post('/register', validateRegister, authController.register);
router.post('/login', validateLogin, authController.login);

// Protected routes
router.get('/me', auth, authController.getMe);
router.put('/profile', auth, validateUpdateProfile, authController.updateProfile);
router.put('/password', auth, validateChangePassword, authController.changePassword);
router.post('/logout', auth, authController.logout);
router.post('/profile-picture', auth, upload.single('profilePicture'), authController.uploadProfilePicture);

module.exports = router;