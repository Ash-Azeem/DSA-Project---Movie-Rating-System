document.addEventListener('DOMContentLoaded', async () => {
  // Initialize services
  const authService = window.authService;
  const movieService = window.movieService;

  // Initialize authentication
  await authService.init();

  // Get movie ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const movieId = urlParams.get('id');

  if (!movieId) {
    window.location.href = 'index.html';
    return;
  }

  // Load movie details
  await loadMovieDetails(movieId);

  // Setup rating modal
  setupRatingModal();
});

// Load movie details
async function loadMovieDetails(movieId) {
  try {
    showLoadingSpinner();
    
    const response = await window.movieService.getMovieById(movieId);
    
    if (response.success) {
      renderMovieDetails(response.data.movie);
    } else {
      throw new Error(response.message || 'Failed to load movie details');
    }
  } catch (error) {
    console.error('Error loading movie details:', error);
    
    const container = document.getElementById('movie-details-container');
    container.innerHTML = `
      <div class="error-message">
        <h2>Error</h2>
        <p>${error.message}</p>
        <a href="index.html" class="back-to-home-btn">
          <i class="fas fa-arrow-left"></i> Back to Home
        </a>
      </div>
    `;
  } finally {
    hideLoadingSpinner();
  }
}

// Render movie details
function renderMovieDetails(movie) {
  const container = document.getElementById('movie-details-container');
  
  container.innerHTML = `
    <div class="movie-details-container">
      <div class="movie-details-poster">
        <img src="${movie.poster_path || 'https://via.placeholder.com/300x450'}" alt="${movie.title}">
      </div>
      <div class="movie-details-info">
        <h1 class="movie-details-title">${movie.title}</h1>
        <div class="movie-details-meta">
          <span>${movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</span>
          <span>${movie.runtime_minutes ? `${movie.runtime_minutes} min` : 'N/A'}</span>
          <div class="movie-details-rating">
            <i class="fas fa-star"></i>
            <span>${movie.avgRating || 'N/A'}</span>
            <span>(${movie.ratingCount || 0} reviews)</span>
          </div>
        </div>
        <p class="movie-details-overview">${movie.overview || 'No description available'}</p>
        <div class="movie-details-actions">
          <button class="play-btn">
            <i class="fas fa-play"></i> Watch Trailer
          </button>
          <button class="add-btn watchlist-btn ${movie.isInWatchlist ? 'added' : ''}" data-id="${movie.movie_id}">
            <i class="fas fa-bookmark"></i> ${movie.isInWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
          </button>
          <button class="rate-btn" data-id="${movie.movie_id}" data-title="${movie.title}">
            <i class="fas fa-star"></i> ${movie.userRating ? `Your Rating: ${movie.userRating}` : 'Rate'}
          </button>
        </div>
        
        <!-- Genre Tags -->
        <div class="movie-detail-section">
          <h3>Genres</h3>
          <div class="genre-tags">
            ${movie.Genres ? movie.Genres.map(genre => `<span class="genre-tag">${genre.name}</span>`).join('') : 'No genres available'}
          </div>
        </div>
        
        <!-- Cast -->
        <div class="movie-detail-section">
          <h3>Cast</h3>
          <div class="role-group">
            <h4>Actors</h4>
            <div class="people-list">
              ${movie.cast ? movie.cast.slice(0, 5).map(actor => `<span class="person-name">${actor.name}</span>`).join('') : 'No cast information available'}
            </div>
          </div>
        </div>
        
        <!-- Crew -->
        <div class="movie-detail-section">
          <h3>Crew</h3>
          <div class="role-group">
            <h4>Directors</h4>
            <div class="people-list">
              ${movie.crew ? movie.crew.filter(person => person.job === 'Director').slice(0, 3).map(director => `<span class="person-name">${director.name}</span>`).join('') : 'No director information available'}
            </div>
          </div>
          <div class="role-group">
            <h4>Writers</h4>
            <div class="people-list">
              ${movie.crew ? movie.crew.filter(person => person.job === 'Writer').slice(0, 3).map(writer => `<span class="person-name">${writer.name}</span>`).join('') : 'No writer information available'}
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Add event listeners to buttons
  const watchlistBtn = container.querySelector('.watchlist-btn');
  const rateBtn = container.querySelector('.rate-btn');
  const playBtn = container.querySelector('.play-btn');

  if (watchlistBtn) {
    watchlistBtn.addEventListener('click', () => {
      window.movieService.toggleWatchlist(movie.movie_id, watchlistBtn);
    });
  }

  if (rateBtn) {
    rateBtn.addEventListener('click', () => {
      window.movieService.openRatingModal(movie.movie_id, movie.title);
    });
  }

  if (playBtn) {
    playBtn.addEventListener('click', () => {
      window.notificationService.info('Trailer functionality coming soon!');
    });
  }
}

// Setup rating modal
function setupRatingModal() {
  const modal = document.getElementById('rating-modal');
  const cancelBtn = document.getElementById('cancel-rating-btn');
  const submitBtn = document.getElementById('submit-rating-btn');
  const stars = modal.querySelectorAll('.star-rating span');

  // Handle cancel
  cancelBtn.onclick = () => {
    modal.style.display = 'none';
  };

  // Handle star clicks
  let selectedRating = 0;
  stars.forEach((star, index) => {
    star.onclick = () => {
      selectedRating = index + 1;
      window.movieService.updateStars(selectedRating);
    };
  });

  // Handle submit
  submitBtn.onclick = async () => {
    if (selectedRating === 0) {
      window.notificationService.show('Please select a rating', 'error');
      return;
    }

    const rateBtn = document.querySelector('.rate-btn');
    const movieId = rateBtn.dataset.id;

    try {
      await window.movieService.rateMovie(movieId, selectedRating);
      modal.style.display = 'none';
      
      // Update the button text
      rateBtn.innerHTML = `<i class="fas fa-star"></i> Your Rating: ${selectedRating}`;
    } catch (error) {
      console.error('Error rating movie:', error);
    }
  };

  // Close modal when clicking outside
  window.onclick = (event) => {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  };
}

// Show loading spinner
function showLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'block';
  }
}

// Hide loading spinner
function hideLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'none';
  }
}