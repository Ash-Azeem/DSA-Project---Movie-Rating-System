class MovieCard {
  static create(movie, options = {}) {
    const {
      showWatchlistButton = true,
      showRatingButton = true,
      showViewButton = true,
      compact = false
    } = options;

    const card = document.createElement('div');
    card.className = `movie-card ${compact ? 'compact' : ''}`;
    
    const posterHeight = compact ? '200px' : '330px';
    const descriptionDisplay = compact ? 'none' : '-webkit-box';

    card.innerHTML = `
      <div class="movie-poster">
        <img src="${movie.poster_path || 'https://via.placeholder.com/300x450'}" alt="${movie.title}">
        <div class="movie-overlay">
          ${showViewButton ? `<button class="view-btn" data-id="${movie.movie_id}"><i class="fas fa-eye"></i></button>` : ''}
          ${showWatchlistButton ? `<button class="watchlist-btn ${movie.isInWatchlist ? 'added' : ''}" data-id="${movie.movie_id}">
            <i class="fas fa-bookmark"></i>
          </button>` : ''}
          ${showRatingButton ? `<button class="rate-btn" data-id="${movie.movie_id}" data-title="${movie.title}">
            <i class="fas fa-star"></i>
          </button>` : ''}
        </div>
      </div>
      <div class="movie-info">
        <h3 class="movie-title">${movie.title}</h3>
        <div class="movie-meta">
          <span>${movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</span>
          <div class="movie-rating">
            <i class="fas fa-star"></i>
            <span>${movie.avgRating || 'N/A'}</span>
          </div>
        </div>
        <p class="movie-description" style="display: ${descriptionDisplay}">${movie.overview || 'No description available'}</p>
      </div>
    `;

    // Add event listeners
    const viewBtn = card.querySelector('.view-btn');
    const watchlistBtn = card.querySelector('.watchlist-btn');
    const rateBtn = card.querySelector('.rate-btn');

    if (viewBtn) {
      viewBtn.addEventListener('click', () => {
        window.location.href = `movie-details.html?id=${movie.movie_id}`;
      });
    }

    if (watchlistBtn) {
      watchlistBtn.addEventListener('click', () => {
        window.movieService.toggleWatchlist(movie.movie_id, watchlistBtn);
      });
    }

    if (rateBtn) {
      rateBtn.addEventListener('click', () => {
        window.movieService.openRatingModal(movie.movie_id, movie.title);
      });
    }

    return card;
  }

  static renderList(movies, containerId, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    if (!movies || movies.length === 0) {
      container.innerHTML = '<p class="no-results">No movies found</p>';
      return;
    }

    movies.forEach(movie => {
      const card = MovieCard.create(movie, options);
      container.appendChild(card);
    });
  }
}

// Export the class
window.MovieCard = MovieCard;