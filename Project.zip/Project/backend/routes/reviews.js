const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const { auth } = require('../middleware/auth');
const { body } = require('express-validator');

// Validation rules
const createReviewValidation = [
  body('movie_id')
    .notEmpty()
    .withMessage('Movie ID is required')
    .isInt({ min: 1 })
    .withMessage('Movie ID must be a positive integer'),
  body('title')
    .optional()
    .isLength({ max: 255 })
    .withMessage('Review title must be less than 255 characters'),
  body('content')
    .notEmpty()
    .withMessage('Review content is required')
    .isLength({ min: 10, max: 5000 })
    .withMessage('Review content must be between 10 and 5000 characters'),
  body('is_spoiler')
    .optional()
    .isBoolean()
    .withMessage('is_spoiler must be a boolean')
];

const updateReviewValidation = [
  body('title')
    .optional()
    .isLength({ max: 255 })
    .withMessage('Review title must be less than 255 characters'),
  body('content')
    .optional()
    .isLength({ min: 10, max: 5000 })
    .withMessage('Review content must be between 10 and 5000 characters'),
  body('is_spoiler')
    .optional()
    .isBoolean()
    .withMessage('is_spoiler must be a boolean')
];

// Public routes
router.get('/movie/:movieId', reviewController.getMovieReviews);
router.get('/:id', reviewController.getReviewById);

// Protected routes
router.post('/', auth, createReviewValidation, reviewController.createReview);
router.put('/:id', auth, updateReviewValidation, reviewController.updateReview);
router.delete('/:id', auth, reviewController.deleteReview);

module.exports = router;