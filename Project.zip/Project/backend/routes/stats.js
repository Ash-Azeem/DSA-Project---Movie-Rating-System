const express = require('express');
const router = express.Router();
const statsController = require('../controllers/statsController');
const { auth } = require('../middleware/auth');

// Public routes
router.get('/database', statsController.getDatabaseStats);
router.get('/years-with-multiple-releases', statsController.getYearsWithMultipleReleases);
router.get('/top-decades-by-runtime', statsController.getTopDecadesByRuntime);
router.get('/genre-distribution', statsController.getGenreDistribution);
router.get('/rating-distribution', statsController.getRatingDistribution);

// Protected routes
router.get('/user-activity', auth, statsController.getUserActivityStats);

module.exports = router;