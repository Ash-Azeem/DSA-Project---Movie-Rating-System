class Header {
  constructor() {
    this.authService = window.authService;
    this.container = document.getElementById('header');
  }

  render() {
    if (!this.container) return;

    this.container.innerHTML = `
      <div class="container header-container">
        <a href="index.html" class="logo">
          <i class="fas fa-film"></i> CineMatch
        </a>
        <nav>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="index.html#recommendations">Recommendations</a></li>
            <li><a href="index.html#genres">Genres</a></li>
            <li><a href="index.html#new-releases">New Releases</a></li>
          </ul>
        </nav>
        <div class="user-menu" id="user-menu">
          <div id="auth-section">
            <a href="login.html" id="login-link">Login</a>
            <a href="register.html" id="register-link">Register</a>
            <div id="user-info" style="display: none;">
              <span id="username-display"></span>
              <button id="logout-btn">Logout</button>
            </div>
          </div>
        </div>
      </div>
    `;

    this.updateAuthUI();
    this.setupEventListeners();
  }

  updateAuthUI() {
    const loginLink = document.getElementById('login-link');
    const registerLink = document.getElementById('register-link');
    const userInfo = document.getElementById('user-info');
    const usernameDisplay = document.getElementById('username-display');
    const logoutBtn = document.getElementById('logout-btn');

    if (this.authService.isLoggedIn()) {
      const user = this.authService.getCurrentUser();
      
      if (loginLink) loginLink.style.display = 'none';
      if (registerLink) registerLink.style.display = 'none';
      if (userInfo) userInfo.style.display = 'flex';
      if (usernameDisplay) usernameDisplay.textContent = user.username;
      if (logoutBtn) {
        logoutBtn.onclick = () => this.authService.logout();
      }
    } else {
      if (loginLink) loginLink.style.display = 'block';
      if (registerLink) registerLink.style.display = 'block';
      if (userInfo) userInfo.style.display = 'none';
    }
  }

  setupEventListeners() {
    // Update active navigation based on current page
    const currentPath = window.location.pathname;
    const navLinks = this.container.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
      link.classList.remove('active');
      
      if (currentPath.endsWith('index.html') || currentPath.endsWith('/')) {
        if (link.getAttribute('href') === 'index.html') {
          link.classList.add('active');
        }
      } else if (currentPath.includes(link.getAttribute('href'))) {
        link.classList.add('active');
      }
    });
  }
}

// Create and export header component
const header = new Header();

// Auto-render when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  header.render();
});

// Export for use in other modules
window.header = header;