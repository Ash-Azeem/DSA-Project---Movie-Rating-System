const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { auth } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public routes
router.get('/:id', userController.getUserProfile);

// Protected routes
router.put('/profile', auth, userController.updateProfile);
router.post('/profile-picture', auth, upload.single('profilePicture'), userController.uploadProfilePicture);
router.get('/ratings', auth, userController.getUserRatings);
router.get('/reviews', auth, userController.getUserReviews);
router.get('/watchlist', auth, userController.getUserWatchlist);
router.delete('/account', auth, userController.deleteAccount);

module.exports = router;