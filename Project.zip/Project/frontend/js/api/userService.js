class UserService {
  constructor() {
    this.apiService = window.apiService;
    this.authService = window.authService;
    this.notificationService = window.notificationService;
  }

  // Get user profile
  async getUserProfile(userId) {
    try {
      const response = await this.apiService.getUserProfile(userId);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Update profile
  async updateProfile(profileData) {
    try {
      const response = await this.apiService.updateProfile(profileData);
      
      if (response.success) {
        this.authService.updateUser(response.data.user);
        this.notificationService.show('Profile updated successfully', 'success');
      }
      
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Change password
  async changePassword(passwordData) {
    try {
      const response = await this.apiService.changePassword(passwordData);
      
      if (response.success) {
        this.notificationService.show('Password changed successfully', 'success');
      }
      
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get user ratings
  async getUserRatings(params = {}) {
    try {
      const response = await this.apiService.getUserRatings(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get user reviews
  async getUserReviews(params = {}) {
    try {
      const response = await this.apiService.getUserReviews(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get user watchlist
  async getUserWatchlist(params = {}) {
    try {
      const response = await this.apiService.getUserWatchlist(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Delete account
  async deleteAccount() {
    try {
      const response = await this.apiService.deleteAccount();
      
      if (response.success) {
        this.notificationService.show('Account deleted successfully', 'success');
        setTimeout(() => {
          this.authService.clearAuth();
        }, 2000);
      }
      
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Upload profile picture
  async uploadProfilePicture(file) {
    try {
      const formData = new FormData();
      formData.append('profilePicture', file);

      const response = await fetch(`${this.apiService.baseURL}/users/profile-picture`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiService.token}`
        },
        body: formData
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Upload failed');
      }

      if (data.success) {
        this.authService.updateUser({ profile_image_url: data.data.profile_image_url });
        this.notificationService.show('Profile picture updated successfully', 'success');
      }

      return data;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Render user ratings
  renderUserRatings(ratings, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    if (!ratings || ratings.length === 0) {
      container.innerHTML = '<p class="no-results">No ratings found</p>';
      return;
    }

    ratings.forEach(rating => {
      const ratingCard = this.createRatingCard(rating);
      container.appendChild(ratingCard);
    });
  }

  // Create rating card
  createRatingCard(rating) {
    const ratingCard = document.createElement('div');
    ratingCard.className = 'rating-card';
    ratingCard.innerHTML = `
      <div class="rating-poster">
        <img src="${rating.Movie.poster_path || 'https://via.placeholder.com/150x225'}" alt="${rating.Movie.title}">
      </div>
      <div class="rating-info">
        <h4>${rating.Movie.title}</h4>
        <div class="rating-meta">
          <span>${rating.Movie.release_date ? new Date(rating.Movie.release_date).getFullYear() : 'N/A'}</span>
          <div class="user-rating">
            <i class="fas fa-star"></i>
            <span>${rating.rating}</span>
          </div>
        </div>
        <p class="rating-date">Rated on ${new Date(rating.timestamp).toLocaleDateString()}</p>
      </div>
    `;

    ratingCard.addEventListener('click', () => {
      window.location.href = `movie-details.html?id=${rating.movie_id}`;
    });

    return ratingCard;
  }

  // Render user reviews
  renderUserReviews(reviews, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    if (!reviews || reviews.length === 0) {
      container.innerHTML = '<p class="no-results">No reviews found</p>';
      return;
    }

    reviews.forEach(review => {
      const reviewCard = this.createReviewCard(review);
      container.appendChild(reviewCard);
    });
  }

  // Create review card
  createReviewCard(review) {
    const reviewCard = document.createElement('div');
    reviewCard.className = 'review-card';
    reviewCard.innerHTML = `
      <div class="review-header">
        <div class="review-movie">
          <img src="${review.Movie.poster_path || 'https://via.placeholder.com/60x90'}" alt="${review.Movie.title}">
          <div>
            <h4>${review.Movie.title}</h4>
            <p>${review.Movie.release_date ? new Date(review.Movie.release_date).getFullYear() : 'N/A'}</p>
          </div>
        </div>
        <div class="review-actions">
          <button class="edit-btn" data-id="${review.review_id}"><i class="fas fa-edit"></i></button>
          <button class="delete-btn" data-id="${review.review_id}"><i class="fas fa-trash"></i></button>
        </div>
      </div>
      <div class="review-content">
        ${review.title ? `<h5>${review.title}</h5>` : ''}
        <p>${review.content}</p>
      </div>
      <div class="review-footer">
        <span class="review-date">${new Date(review.created_at).toLocaleDateString()}</span>
        ${review.updated_at !== review.created_at ? '<span class="updated-indicator">Edited</span>' : ''}
      </div>
    `;

    // Add event listeners
    const editBtn = reviewCard.querySelector('.edit-btn');
    const deleteBtn = reviewCard.querySelector('.delete-btn');

    editBtn.addEventListener('click', () => {
      this.editReview(review.review_id);
    });

    deleteBtn.addEventListener('click', () => {
      this.deleteReview(review.review_id);
    });

    return reviewCard;
  }

  // Edit review
  editReview(reviewId) {
    // This would open a modal or navigate to an edit page
    console.log('Edit review:', reviewId);
  }

  // Delete review
  async deleteReview(reviewId) {
    if (!confirm('Are you sure you want to delete this review?')) {
      return;
    }

    try {
      await this.apiService.deleteReview(reviewId);
      this.notificationService.show('Review deleted successfully', 'success');
      // Refresh the reviews list
      location.reload();
    } catch (error) {
      this.notificationService.show(error.message, 'error');
    }
  }
}

// Create a singleton instance
const userService = new UserService();

// Export the instance
window.userService = userService;