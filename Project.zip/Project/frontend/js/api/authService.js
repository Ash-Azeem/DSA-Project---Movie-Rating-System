class AuthService {
  constructor() {
    this.apiService = window.apiService;
    this.currentUser = null;
  }

  // Initialize auth state
  async init() {
    const token = localStorage.getItem('token');
    
    if (token) {
      try {
        const response = await this.apiService.getCurrentUser();
        if (response.success) {
          this.currentUser = response.data.user;
          this.updateUI();
          return true;
        } else {
          this.logout();
          return false;
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        this.logout();
        return false;
      }
    }
    
    return false;
  }

  // Register a new user
  async register(userData) {
    try {
      const response = await this.apiService.register(userData);
      
      if (response.success) {
        this.currentUser = response.data.user;
        this.setToken(response.data.token);
        this.updateUI();
        return { success: true };
      } else {
        return { success: false, message: response.message || 'Registration failed' };
      }
    } catch (error) {
      return { success: false, message: error.message || 'Registration failed' };
    }
  }

  // Login user
  async login(credentials) {
    try {
      const response = await this.apiService.login(credentials);
      
      if (response.success) {
        this.currentUser = response.data.user;
        this.setToken(response.data.token);
        this.updateUI();
        return { success: true };
      } else {
        return { success: false, message: response.message || 'Login failed' };
      }
    } catch (error) {
      return { success: false, message: error.message || 'Login failed' };
    }
  }

  // Logout user
  async logout() {
    try {
      await this.apiService.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.clearAuth();
    }
  }

  // Clear authentication state
  clearAuth() {
    this.apiService.clearToken();
    this.currentUser = null;
    this.updateUI();
    
    // Redirect to home page if not already there
    if (!window.location.pathname.endsWith('index.html') && !window.location.pathname.endsWith('/')) {
      window.location.href = 'index.html';
    }
  }

  // Set token
  setToken(token) {
    this.apiService.setToken(token);
  }

  // Update UI based on auth state
  updateUI() {
    const loginLink = document.getElementById('login-link');
    const registerLink = document.getElementById('register-link');
    const userInfo = document.getElementById('user-info');
    const usernameDisplay = document.getElementById('username-display');
    const logoutBtn = document.getElementById('logout-btn');

    if (this.currentUser) {
      // User is logged in
      if (loginLink) loginLink.style.display = 'none';
      if (registerLink) registerLink.style.display = 'none';
      if (userInfo) userInfo.style.display = 'flex';
      if (usernameDisplay) usernameDisplay.textContent = this.currentUser.username;
      if (logoutBtn) {
        logoutBtn.onclick = () => this.logout();
      }
    } else {
      // User is not logged in
      if (loginLink) loginLink.style.display = 'block';
      if (registerLink) registerLink.style.display = 'block';
      if (userInfo) userInfo.style.display = 'none';
    }
  }

  // Check if user is logged in
  isLoggedIn() {
    return this.currentUser !== null;
  }

  // Get current user
  getCurrentUser() {
    return this.currentUser;
  }

  // Update current user data
  updateUser(userData) {
    if (this.currentUser) {
      this.currentUser = { ...this.currentUser, ...userData };
    }
  }
}

// Create a singleton instance
const authService = new AuthService();

// Export the instance
window.authService = authService;