class Pagination {
  static create(page, pages, containerId, onPageChange) {
    const container = document.getElementById(containerId);
    if (!container || pages <= 1) return;

    container.innerHTML = '';

    const paginationContainer = document.createElement('div');
    paginationContainer.className = 'pagination-container';

    // Previous button
    const prevBtn = document.createElement('button');
    prevBtn.className = 'pagination-btn';
    prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
    prevBtn.disabled = page === 1;
    prevBtn.addEventListener('click', () => {
      if (page > 1) {
        onPageChange(page - 1);
      }
    });
    paginationContainer.appendChild(prevBtn);

    // Page numbers
    const maxVisiblePages = 5;
    let startPage = Math.max(1, page - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(pages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    if (startPage > 1) {
      const firstPageBtn = Pagination.createPageButton(1, onPageChange);
      paginationContainer.appendChild(firstPageBtn);

      if (startPage > 2) {
        const dots = document.createElement('span');
        dots.className = 'pagination-dots';
        dots.textContent = '...';
        paginationContainer.appendChild(dots);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      const pageBtn = Pagination.createPageButton(i, onPageChange, i === page);
      paginationContainer.appendChild(pageBtn);
    }

    if (endPage < pages) {
      if (endPage < pages - 1) {
        const dots = document.createElement('span');
        dots.className = 'pagination-dots';
        dots.textContent = '...';
        paginationContainer.appendChild(dots);
      }

      const lastPageBtn = Pagination.createPageButton(pages, onPageChange);
      paginationContainer.appendChild(lastPageBtn);
    }

    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.className = 'pagination-btn';
    nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
    nextBtn.disabled = page === pages;
    nextBtn.addEventListener('click', () => {
      if (page < pages) {
        onPageChange(page + 1);
      }
    });
    paginationContainer.appendChild(nextBtn);

    container.appendChild(paginationContainer);
  }

  static createPageButton(pageNum, onPageChange, isActive = false) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `pagination-btn ${isActive ? 'active' : ''}`;
    pageBtn.textContent = pageNum;
    pageBtn.addEventListener('click', () => {
      onPageChange(pageNum);
    });
    return pageBtn;
  }

  static create(pageInfo, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const { page, limit, total, pages } = pageInfo;
    
    const info = document.createElement('div');
    info.className = 'pagination-info';
    info.innerHTML = `
      <span>Showing ${((page - 1) * limit) + 1} to ${Math.min(page * limit, total)} of ${total} results</span>
      <span>Page ${page} of ${pages}</span>
    `;

    container.appendChild(info);
  }
}

// Export the class
window.Pagination = Pagination;