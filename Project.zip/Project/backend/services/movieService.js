const { Movie, Genre, Rating, Review, User, Watchlist } = require('../models');
const { Op } = require('sequelize');
const sequelize = require('../config/database');

const getMovieRecommendations = async (userId, limit = 10) => {
  try {
    // Get user's highly rated movies (4+ stars)
    const userHighlyRatedMovies = await sequelize.query(`
      SELECT movie_id, rating
      FROM ratings
      WHERE user_id = ? AND rating >= 4
      ORDER BY rating DESC
      LIMIT 10
    `, {
      replacements: [userId],
      type: sequelize.QueryTypes.SELECT
    });

    if (userHighlyRatedMovies.length === 0) {
      // If user hasn't rated any movies, return top rated movies
      return getTopRatedMovies(limit);
    }

    // Get genres from user's highly rated movies
    const movieIds = userHighlyRatedMovies.map(m => m.movie_id);
    
    const genres = await sequelize.query(`
      SELECT DISTINCT g.name, COUNT(*) as count
      FROM genres g
      JOIN movie_genres mg ON g.genre_id = mg.genre_id
      WHERE mg.movie_id IN (${movieIds.join(',')})
      GROUP BY g.genre_id, g.name
      ORDER BY count DESC
      LIMIT 3
    `, {
      type: sequelize.QueryTypes.SELECT
    });

    // Get movies from these genres that user hasn't rated
    const genreNames = genres.map(g => g.name);
    const genrePlaceholders = genreNames.map(() => '?').join(',');
    
    const recommendations = await sequelize.query(`
      SELECT DISTINCT m.*, 
             COALESCE(AVG(r.rating), 0) as avgRating,
             COUNT(r.rating) as ratingCount
      FROM movies m
      JOIN movie_genres mg ON m.movie_id = mg.movie_id
      JOIN genres g ON mg.genre_id = g.genre_id
      LEFT JOIN ratings r ON m.movie_id = r.movie_id
      WHERE g.name IN (${genrePlaceholders})
        AND m.movie_id NOT IN (
          SELECT movie_id FROM ratings WHERE user_id = ?
        )
      GROUP BY m.movie_id
      ORDER BY avgRating DESC, ratingCount DESC
      LIMIT ?
    `, {
      replacements: [...genreNames, userId, limit],
      type: sequelize.QueryTypes.SELECT
    });

    return recommendations.map(movie => ({
      ...movie,
      avgRating: parseFloat(movie.avgRating).toFixed(1)
    }));
  } catch (error) {
    console.error('Error getting movie recommendations:', error);
    throw error;
  }
};

const getTopRatedMovies = async (limit = 10) => {
  try {
    const topRatedMovies = await sequelize.query(`
      SELECT m.*, 
             COALESCE(AVG(r.rating), 0) as avgRating, 
             COUNT(r.rating) as ratingCount
      FROM movies m
      LEFT JOIN ratings r ON m.movie_id = r.movie_id
      GROUP BY m.movie_id
      HAVING ratingCount >= 5
      ORDER BY avgRating DESC, ratingCount DESC
      LIMIT ?
    `, {
      replacements: [limit],
      type: sequelize.QueryTypes.SELECT
    });

    return topRatedMovies.map(movie => ({
      ...movie,
      avgRating: parseFloat(movie.avgRating).toFixed(1)
    }));
  } catch (error) {
    console.error('Error getting top rated movies:', error);
    throw error;
  }
};

const getSimilarMovies = async (movieId, limit = 10) => {
  try {
    // Get the movie's genres
    const movieGenres = await sequelize.query(`
      SELECT g.genre_id
      FROM genres g
      JOIN movie_genres mg ON g.genre_id = mg.genre_id
      WHERE mg.movie_id = ?
    `, {
      replacements: [movieId],
      type: sequelize.QueryTypes.SELECT
    });

    if (movieGenres.length === 0) {
      return [];
    }

    const genreIds = movieGenres.map(g => g.genre_id);
    const genrePlaceholders = genreIds.map(() => '?').join(',');

    // Get movies with similar genres
    const similarMovies = await sequelize.query(`
      SELECT DISTINCT m.*, 
             COALESCE(AVG(r.rating), 0) as avgRating,
             COUNT(r.rating) as ratingCount,
             COUNT(mg.movie_id) as genreMatchCount
      FROM movies m
      JOIN movie_genres mg ON m.movie_id = mg.movie_id
      LEFT JOIN ratings r ON m.movie_id = r.movie_id
      WHERE mg.genre_id IN (${genrePlaceholders})
        AND m.movie_id != ?
      GROUP BY m.movie_id
      HAVING genreMatchCount > 0
      ORDER BY genreMatchCount DESC, avgRating DESC
      LIMIT ?
    `, {
      replacements: [...genreIds, movieId, limit],
      type: sequelize.QueryTypes.SELECT
    });

    return similarMovies.map(movie => ({
      ...movie,
      avgRating: parseFloat(movie.avgRating).toFixed(1)
    }));
  } catch (error) {
    console.error('Error getting similar movies:', error);
    throw error;
  }
};

module.exports = {
  getMovieRecommendations,
  getTopRatedMovies,
  getSimilarMovies
};