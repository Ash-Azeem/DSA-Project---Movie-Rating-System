document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('register-form');
  const authService = window.authService;
  const notificationService = window.notificationService;

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(registerForm);
    const password = formData.get('password');
    const confirmPassword = formData.get('confirmPassword');

    // Validate passwords match
    if (password !== confirmPassword) {
      notificationService.error('Passwords do not match');
      return;
    }

    const userData = {
      username: formData.get('username'),
      email: formData.get('email'),
      password: password,
      first_name: formData.get('first_name'),
      last_name: formData.get('last_name'),
      date_of_birth: formData.get('date_of_birth')
    };

    try {
      const result = await authService.register(userData);
      
      if (result.success) {
        notificationService.success('Registration successful! Redirecting...');
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1500);
      } else {
        notificationService.error(result.message || 'Registration failed');
      }
    } catch (error) {
      console.error('Registration error:', error);
      notificationService.error('An error occurred during registration');
    }
  });
});