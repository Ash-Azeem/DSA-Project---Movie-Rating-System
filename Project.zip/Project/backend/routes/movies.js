const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');
const { auth, optionalAuth } = require('../middleware/auth');

// Public routes
router.get('/', optionalAuth, movieController.getMovies);
router.get('/top-rated', movieController.getTopRatedMovies);
router.get('/new-releases', movieController.getNewReleases);
router.get('/genre/:genre', movieController.getMoviesByGenre);
router.get('/search', movieController.searchMovies);
router.get('/:id', optionalAuth, movieController.getMovieById);

// Protected routes
router.get('/recommendations', auth, movieController.getRecommendations);
router.post('/:id/rate', auth, movieController.rateMovie);

module.exports = router;