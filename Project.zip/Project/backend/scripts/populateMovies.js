const axios = require('axios');
const sequelize = require('../config/database');
const { Movie, Genre, Person, Cast, Crew, MovieGenre } = require('../models');

// TMDB API configuration
const TMDB_API_KEY = '5a20fe5039d5b66297e705eae5ee68d7';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';

// Fetch popular movies from TMDB
async function fetchPopularMovies(page = 1, limit = 50) {
  try {
    console.log(`📥 Fetching page ${page} of popular movies...`);
    const response = await axios.get(`${TMDB_BASE_URL}/movie/popular`, {
      params: {
        api_key: TMDB_API_KEY,
        language: 'en-US',
        page: page
      }
    });

    return response.data.results.slice(0, limit);
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    return [];
  }
}

// Get or create a genre
async function getOrCreateGenre(name) {
  try {
    // Try to find the genre first
    const [genre] = await Genre.findAll({
      where: { name }
    });
    
    if (genre.length > 0) {
      return genre[0];
    }
    
    // If not found, create it
    return await Genre.create({ name });
  } catch (error) {
    console.error(`Error creating genre ${name}:`, error);
    return null;
  }
}

// Get or create a person
async function getOrCreatePerson(name, biography, dateOfBirth, placeOfBirth) {
  try {
    // Try to find the person first
    const [person] = await Person.findAll({
      where: { name }
    });
    
    if (person.length > 0) {
      return person[0];
    }
    
    // If not found, create it
    return await Person.create({
      name,
      biography: biography || '',
      date_of_birth: dateOfBirth ? new Date(dateOfBirth) : null,
      place_of_birth: placeOfBirth || ''
    });
  } catch (error) {
    console.error(`Error creating person ${name}:`, error);
    return null;
  }
}

// Process and save a movie
async function processAndSaveMovie(movieData) {
  try {
    // Extract basic movie information
    const {
      id: tmdbId,
      title,
      original_title: originalTitle,
      tagline,
      overview,
      release_date,
      runtime,
      budget,
      revenue,
      poster_path: posterPath,
      backdrop_path: backdropPath
    } = movieData.details;

    // Create or update the movie
    const [movie, created] = await Movie.findOrCreate({
      where: { title },
      defaults: {
        title,
        original_title: originalTitle,
        tagline,
        overview,
        release_date: release_date ? new Date(release_date) : null,
        runtime_minutes: runtime,
        budget,
        revenue,
        poster_path: posterPath ? `${TMDB_IMAGE_BASE}${posterPath}` : null,
        backdrop_path: backdropPath ? `${TMDB_IMAGE_BASE}${backdropPath}` : null,
        imdb_id: tmdbId.toString()
      }
    });

    // Process genres
    if (movieData.details.genres && movieData.details.genres.length > 0) {
      for (const genre of movieData.details.genres) {
        const genreRecord = await getOrCreateGenre(genre.name);
        if (genreRecord) {
          await MovieGenre.findOrCreate({
            where: {
              movie_id: movie.movie_id,
              genre_id: genreRecord.genre_id
            }
          });
        }
      }
    }

    // Process cast
    if (movieData.credits && movieData.credits.cast && movieData.credits.cast.length > 0) {
      for (let i = 0; i < Math.min(10, movieData.credits.cast.length); i++) {
        const castMember = movieData.credits.cast[i];
        const personRecord = await getOrCreatePerson(
          castMember.name,
          castMember.biography,
          castMember.birthday,
          castMember.place_of_birth
        );

        if (personRecord) {
          await Cast.findOrCreate({
            where: {
              movie_id: movie.movie_id,
              person_id: personRecord.person_id
            },
            defaults: {
              character_name: castMember.character,
              cast_order: i + 1
            }
          });
        }
      }
    }

    // Process crew (directors, writers, etc.)
    if (movieData.credits && movieData.credits.crew && movieData.credits.crew.length > 0) {
      for (const crewMember of movieData.credits.crew) {
        const personRecord = await getOrCreatePerson(
          crewMember.name,
          crewMember.biography,
          crewMember.birthday,
          crewMember.place_of_birth
        );

        if (personRecord) {
          await Crew.findOrCreate({
            where: {
              movie_id: movie.movie_id,
              person_id: personRecord.person_id
            },
            defaults: {
              department: crewMember.department,
              job: crewMember.job
            }
          });
        }
      }
    }

    console.log(`✓ Processed movie: ${title}`);
    return movie;
  } catch (error) {
    console.error(`Error processing movie ${movieData.details.title}:`, error);
    return null;
  }
}

// Main function to populate the database
async function populateDatabase() {
  try {
    console.log('🎬 Starting database population...');
    
    // Fetch multiple pages of popular movies
    let allMovies = [];
    const totalPages = 20; // Fetch 20 pages (1000 movies total)
    
    for (let page = 1; page <= totalPages; page++) {
      const movies = await fetchPopularMovies(page, 50);
      allMovies = [...allMovies, ...movies];
      
      // Add a delay to avoid hitting rate limits
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    console.log(`📥 Fetched ${allMovies.length} movies. Processing details...`);
    
    // Fetch detailed information for each movie
    const detailedMovies = [];
    const batchSize = 50; // Process in batches to avoid overwhelming the API
    
    for (let i = 0; i < allMovies.length; i += batchSize) {
      const batch = allMovies.slice(i, i + batchSize);
      console.log(`📝 Processing batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(allMovies.length/batchSize)} (${batch.length} movies)`);
      
      const batchPromises = batch.map(async (movie, index) => {
        console.log(`  📝 Fetching details for movie ${i + index + 1}/${allMovies.length}: ${movie.title}`);
        return await fetchMovieDetails(movie.id);
      });
      
      const batchResults = await Promise.all(batchPromises);
      detailedMovies.push(...batchResults.filter(result => result !== null));
      
      // Add a delay between batches
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    
    console.log(`🎬 Processing ${detailedMovies.length} movies...`);
    
    // Process and save each movie
    let processedCount = 0;
    for (const movieData of detailedMovies) {
      const movie = await processAndSaveMovie(movieData);
      if (movie) {
        processedCount++;
        if (processedCount % 10 === 0) {
          console.log(`  ✅ Processed ${processedCount} movies...`);
        }
      }
      
      // Small delay to prevent overwhelming the database
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    console.log(`✅ Database population complete! Processed ${processedCount} movies.`);
  } catch (error) {
    console.error('❌ Error populating database:', error);
  } finally {
    // Close the database connection
    await sequelize.close();
    console.log('🔌 Database connection closed.');
  }
}

// Fetch movie details including cast, crew, and genres
async function fetchMovieDetails(movieId) {
  try {
    const [detailsResponse, creditsResponse] = await Promise.all([
      axios.get(`${TMDB_BASE_URL}/movie/${movieId}`, {
        params: {
          api_key: TMDB_API_KEY,
          language: 'en-US',
          append_to_response: 'credits,videos'
        }
      }),
      axios.get(`${TMDB_BASE_URL}/movie/${movieId}/credits`, {
        params: {
          api_key: TMDB_API_KEY
        }
      })
    ]);

    return {
      details: detailsResponse.data,
      credits: creditsResponse.data
    };
  } catch (error) {
    console.error(`Error fetching details for movie ${movieId}:`, error);
    return null;
  }
}

// Run the population script
populateDatabase();