const express = require('express');
const router = express.Router();
const watchlistController = require('../controllers/watchlistController');
const { auth } = require('../middleware/auth');
const { body } = require('express-validator');

// Validation rules
const addToWatchlistValidation = [
  body('movie_id')
    .notEmpty()
    .withMessage('Movie ID is required')
    .isInt({ min: 1 })
    .withMessage('Movie ID must be a positive integer')
];

// Protected routes
router.post('/', auth, addToWatchlistValidation, watchlistController.addToWatchlist);
router.delete('/:movieId', auth, watchlistController.removeFromWatchlist);
router.get('/', auth, watchlistController.getWatchlist);
router.get('/check/:movieId', auth, watchlistController.checkInWatchlist);

module.exports = router;