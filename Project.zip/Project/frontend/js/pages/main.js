// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', async () => {
  // Initialize services
  const authService = window.authService;
  const movieService = window.movieService;
  const notificationService = window.notificationService;

  // Initialize authentication
  await authService.init();

  // Load initial data
  loadInitialData();

  // Setup event listeners
  setupEventListeners();
});

// Load initial data
async function loadInitialData() {
  try {
    // Load recommended movies
    await loadRecommendedMovies();

    // Load new releases
    await loadNewReleases();

    // Load database statistics
    await loadDatabaseStatistics();

    // Load analytics data
    await loadAnalyticsData();
  } catch (error) {
    console.error('Error loading initial data:', error);
  } finally {
    hideLoadingSpinner();
  }
}

// Setup event listeners
function setupEventListeners() {
  // Setup explore controls
  const genreSelect = document.getElementById('genre-select');
  const browseGenreBtn = document.getElementById('browse-genre-btn');
  const topRatedBtn = document.getElementById('top-rated-btn');

  if (genreSelect && browseGenreBtn) {
    // Load genres
    loadGenres();

    browseGenreBtn.addEventListener('click', () => {
      const genre = genreSelect.value;
      if (genre) {
        window.location.href = `search.html?genre=${encodeURIComponent(genre)}`;
      }
    });
  }

  if (topRatedBtn) {
    topRatedBtn.addEventListener('click', () => {
      window.location.href = 'search.html?sort=rating-desc';
    });
  }

  // Setup movie controls
  setupMovieControls();

  // Setup genre cards
  setupGenreCards();

  // Setup search
  setupSearch();
}

// Load genres
async function loadGenres() {
  try {
    // In a real implementation, you would fetch genres from the API
    // For now, we'll use hardcoded genres
    const genres = [
      'Action', 'Adventure', 'Animation', 'Comedy', 'Crime',
      'Documentary', 'Drama', 'Family', 'Fantasy', 'History',
      'Horror', 'Music', 'Mystery', 'Romance', 'Science Fiction',
      'TV Movie', 'Thriller', 'War', 'Western'
    ];

    const genreSelect = document.getElementById('genre-select');
    if (genreSelect) {
      genres.forEach(genre => {
        const option = document.createElement('option');
        option.value = genre.toLowerCase().replace(' ', '-');
        option.textContent = genre;
        genreSelect.appendChild(option);
      });
    }
  } catch (error) {
    console.error('Error loading genres:', error);
  }
}

// Setup movie controls
function setupMovieControls() {
  // Recommended movies controls
  setupMovieSectionControls(
    'recommended-sort',
    'recommended-limit',
    (sort, limit) => {
      loadRecommendedMovies(1, sort, limit);
    }
  );

  // New releases controls
  setupMovieSectionControls(
    'new-releases-sort',
    'new-releases-limit',
    (sort, limit) => {
      loadNewReleases(1, sort, limit);
    }
  );
}

// Setup movie section controls
function setupMovieSectionControls(sortId, limitId, callback) {
  const sortSelect = document.getElementById(sortId);
  const limitSelect = document.getElementById(limitId);

  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      const sort = sortSelect.value;
      const limit = limitSelect ? limitSelect.value : '8';
      callback(sort, limit);
    });
  }

  if (limitSelect) {
    limitSelect.addEventListener('change', () => {
      const sort = sortSelect ? sortSelect.value : 'title-asc';
      const limit = limitSelect.value;
      callback(sort, limit);
    });
  }
}

// Setup genre cards
function setupGenreCards() {
  const genreCards = document.querySelectorAll('.genre-card');
  
  genreCards.forEach(card => {
    card.addEventListener('click', () => {
      const genre = card.dataset.genre;
      window.location.href = `search.html?genre=${encodeURIComponent(genre)}`;
    });
  });
}

// Setup search
function setupSearch() {
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const searchDropdown = document.getElementById('search-dropdown');

  if (!searchInput || !searchBtn || !searchDropdown) return;

  let searchTimeout;

  // Handle search input
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    const query = searchInput.value.trim();

    if (query.length < 2) {
      searchDropdown.classList.remove('active');
      return;
    }

    searchTimeout = setTimeout(() => {
      performSearch(query);
    }, 300);
  });

  // Handle search button click
  searchBtn.addEventListener('click', () => {
    const query = searchInput.value.trim();
    if (query) {
      window.location.href = `search.html?q=${encodeURIComponent(query)}`;
    }
  });

  // Handle Enter key in search input
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const query = searchInput.value.trim();
      if (query) {
        window.location.href = `search.html?q=${encodeURIComponent(query)}`;
      }
    }
  });

  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
      searchDropdown.classList.remove('active');
    }
  });
}

// Perform search
async function performSearch(query) {
  try {
    const response = await window.movieService.searchMovies(query, { limit: 5 });
    displaySearchResults(response.data.movies, query);
  } catch (error) {
    console.error('Search error:', error);
  }
}

// Display search results
function displaySearchResults(movies, query) {
  const searchDropdown = document.getElementById('search-dropdown');
  if (!searchDropdown) return;

  searchDropdown.innerHTML = '';

  if (!movies || movies.length === 0) {
    searchDropdown.innerHTML = '<div class="search-result-item">No results found</div>';
    searchDropdown.classList.add('active');
    return;
  }

  movies.forEach(movie => {
    const resultItem = document.createElement('div');
    resultItem.className = 'search-result-item';
    
    // Highlight matching text
    const highlightedTitle = movie.title.replace(
      new RegExp(query, 'gi'),
      match => `<mark>${match}</mark>`
    );
    
    resultItem.innerHTML = `
      <img src="${movie.poster_path || 'https://via.placeholder.com/40x60'}" alt="${movie.title}">
      <div class="search-result-item-info">
        <div class="search-result-item-title">${highlightedTitle}</div>
        <div class="search-result-item-year">${movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</div>
      </div>
    `;
    
    resultItem.addEventListener('click', () => {
      window.location.href = `movie-details.html?id=${movie.movie_id}`;
    });
    
    searchDropdown.appendChild(resultItem);
  });

  searchDropdown.classList.add('active');
}

// Load recommended movies
async function loadRecommendedMovies(page = 1, sort = 'rating-desc', limit = '8') {
  try {
    showLoadingSpinner();
    
    const params = { page, sort };
    if (limit !== 'all') {
      params.limit = parseInt(limit);
    }
    
    const response = await window.movieService.getRecommendations(params);
    
    if (response.success) {
      window.MovieCard.renderList(response.data.movies, 'recommended-movies');
      window.Pagination.create(
        response.data.pagination.page,
        response.data.pagination.pages,
        'recommended-pagination',
        (newPage) => loadRecommendedMovies(newPage, sort, limit)
      );
    }
  } catch (error) {
    console.error('Error loading recommended movies:', error);
  } finally {
    hideLoadingSpinner();
  }
}

// Load new releases
async function loadNewReleases(page = 1, sort = 'year-desc', limit = '8') {
  try {
    showLoadingSpinner();
    
    const params = { page, sort };
    if (limit !== 'all') {
      params.limit = parseInt(limit);
    }
    
    const response = await window.movieService.getNewReleases(params);
    
    if (response.success) {
      window.MovieCard.renderList(response.data.movies, 'new-releases-movies');
      window.Pagination.create(
        response.data.pagination.page,
        response.data.pagination.pages,
        'new-releases-pagination',
        (newPage) => loadNewReleases(newPage, sort, limit)
      );
    }
  } catch (error) {
    console.error('Error loading new releases:', error);
  } finally {
    hideLoadingSpinner();
  }
}

// Load database statistics
async function loadDatabaseStatistics() {
  try {
    const response = await window.apiService.getDatabaseStats();
    
    if (response.success) {
      const stats = response.data.stats;
      
      // Update stat cards
      updateStatCard('total-movies', stats.totalMovies);
      updateStatCard('total-users', stats.totalUsers);
      updateStatCard('total-genres', stats.totalGenres);
      updateStatCard('avg-runtime', stats.avgRuntime);
      updateStatCard('oldest-year', stats.oldestYear);
      updateStatCard('latest-year', stats.latestYear);
      updateStatCard('total-runtime', stats.totalRuntime);
      updateStatCard('avg-rating', stats.avgRating);
    }
  } catch (error) {
    console.error('Error loading database statistics:', error);
  }
}

// Update stat card
function updateStatCard(id, value) {
  const element = document.getElementById(id);
  if (element) {
    element.textContent = value;
  }
}

// Load analytics data
async function loadAnalyticsData() {
  try {
    // Load years with multiple releases
    const yearsResponse = await window.apiService.getYearsWithMultipleReleases();
    
    if (yearsResponse.success) {
      const yearsList = document.getElementById('movies-by-year-list');
      if (yearsList) {
        yearsList.innerHTML = '';
        
        if (yearsResponse.data.years.length === 0) {
          yearsList.innerHTML = '<p>No data available</p>';
        } else {
          const ul = document.createElement('ul');
          
          yearsResponse.data.years.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.year}: ${item.count} movies`;
            ul.appendChild(li);
          });
          
          yearsList.appendChild(ul);
        }
      }
    }

    // Load top decades by runtime
    const decadesResponse = await window.apiService.getTopDecadesByRuntime();
    
    if (decadesResponse.success) {
      const decadesList = document.getElementById('runtime-by-decade-list');
      if (decadesList) {
        decadesList.innerHTML = '';
        
        if (decadesResponse.data.decades.length === 0) {
          decadesList.innerHTML = '<p>No data available</p>';
        } else {
          const ul = document.createElement('ul');
          
          decadesResponse.data.decades.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.decade}: ${item.avgRuntime} minutes average`;
            ul.appendChild(li);
          });
          
          decadesList.appendChild(ul);
        }
      }
    }
  } catch (error) {
    console.error('Error loading analytics data:', error);
  }
}

// Show loading spinner
function showLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'block';
  }
}

// Hide loading spinner
function hideLoadingSpinner() {
  const spinner = document.getElementById('loading-spinner');
  if (spinner) {
    spinner.style.display = 'none';
  }
}