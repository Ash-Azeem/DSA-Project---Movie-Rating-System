class NotificationService {
  constructor() {
    this.container = document.getElementById('notification');
    this.timeout = null;
  }

  show(message, type = 'success') {
    if (!this.container) return;

    // Clear any existing timeout
    if (this.timeout) {
      clearTimeout(this.timeout);
    }

    // Set message and type
    this.container.textContent = message;
    this.container.className = `notification ${type}`;

    // Show notification
    this.container.classList.add('show');

    // Hide after 3 seconds
    this.timeout = setTimeout(() => {
      this.container.classList.remove('show');
    }, 3000);
  }

  // Show success notification
  success(message) {
    this.show(message, 'success');
  }

  // Show error notification
  error(message) {
    this.show(message, 'error');
  }

  // Show info notification
  info(message) {
    this.show(message, 'info');
  }

  // Show warning notification
  warning(message) {
    this.show(message, 'warning');
  }
}

// Create a singleton instance
const notificationService = new NotificationService();

// Export the instance
window.notificationService = notificationService;