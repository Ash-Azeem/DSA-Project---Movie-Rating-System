class Footer {
  constructor() {
    this.container = document.getElementById('footer');
  }

  render() {
    if (!this.container) return;

    this.container.innerHTML = `
      <div class="container">
        <div class="footer-content">
          <div class="footer-section">
            <h3>CineMatch</h3>
            <p>Your personalized movie recommendation system</p>
            <div class="social-links">
              <a href="#"><i class="fab fa-facebook"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
          <div class="footer-section">
            <h4>Navigation</h4>
            <ul>
              <li><a href="index.html">Home</a></li>
              <li><a href="index.html#recommendations">Recommendations</a></li>
              <li><a href="index.html#genres">Genres</a></li>
              <li><a href="index.html#new-releases">New Releases</a></li>
            </ul>
          </div>
          <div class="footer-section">
            <h4>Legal</h4>
            <ul>
              <li><a href="#">Terms of Service</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Cookie Policy</a></li>
              <li><a href="#">DMCA</a></li>
            </ul>
          </div>
          <div class="footer-section">
            <h4>Newsletter</h4>
            <p>Subscribe to get updates on new movies and recommendations</p>
            <form class="newsletter-form">
              <input type="email" placeholder="Your email address">
              <button type="submit">Subscribe</button>
            </form>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 CineMatch. All rights reserved.</p>
        </div>
      </div>
    `;

    this.setupEventListeners();
  }

  setupEventListeners() {
    // Newsletter form submission
    const newsletterForm = this.container.querySelector('.newsletter-form');
    if (newsletterForm) {
      newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = newsletterForm.querySelector('input[type="email"]').value;
        
        if (email) {
          window.notificationService.success('Thank you for subscribing to our newsletter!');
          newsletterForm.reset();
        }
      });
    }
  }
}

// Create and export footer component
const footer = new Footer();

// Auto-render when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  footer.render();
});

// Export for use in other modules
window.footer = footer;