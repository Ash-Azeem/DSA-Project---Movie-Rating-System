class MovieService {
  constructor() {
    this.apiService = window.apiService;
    this.authService = window.authService;
    this.notificationService = window.notificationService;
  }

  // Get movies with pagination, filtering, and sorting
  async getMovies(params = {}) {
    try {
      const response = await this.apiService.getMovies(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get movie by ID
  async getMovieById(id) {
    try {
      const response = await this.apiService.getMovieById(id);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get top rated movies
  async getTopRatedMovies(params = {}) {
    try {
      const response = await this.apiService.getTopRatedMovies(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get new releases
  async getNewReleases(params = {}) {
    try {
      const response = await this.apiService.getNewReleases(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get movies by genre
  async getMoviesByGenre(genre, params = {}) {
    try {
      const response = await this.apiService.getMoviesByGenre(genre, params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get recommendations
  async getRecommendations(params = {}) {
    try {
      const response = await this.apiService.getRecommendations(params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Search movies
  async searchMovies(query, params = {}) {
    try {
      const response = await this.apiService.searchMovies(query, params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Rate a movie
  async rateMovie(movieId, rating) {
    try {
      if (!this.authService.isLoggedIn()) {
        this.notificationService.show('Please login to rate a movie', 'error');
        return { success: false };
      }

      const response = await this.apiService.rateMovie(movieId, rating);
      this.notificationService.show('Rating submitted successfully', 'success');
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Get movie reviews
  async getMovieReviews(movieId, params = {}) {
    try {
      const response = await this.apiService.getMovieReviews(movieId, params);
      return response;
    } catch (error) {
      this.notificationService.show(error.message, 'error');
      throw error;
    }
  }

  // Toggle watchlist
  async toggleWatchlist(movieId, button) {
    try {
      if (!this.authService.isLoggedIn()) {
        this.notificationService.show('Please login to add to watchlist', 'error');
        return;
      }

      const isInWatchlist = button.classList.contains('added');
      
      if (isInWatchlist) {
        await this.apiService.removeFromWatchlist(movieId);
        button.classList.remove('added');
        this.notificationService.show('Removed from watchlist', 'success');
      } else {
        await this.apiService.addToWatchlist(movieId);
        button.classList.add('added');
        this.notificationService.show('Added to watchlist', 'success');
      }
    } catch (error) {
      this.notificationService.show(error.message, 'error');
    }
  }

  // Check if movie is in watchlist
  async checkWatchlist(movieId) {
    try {
      if (!this.authService.isLoggedIn()) {
        return false;
      }

      const response = await this.apiService.checkInWatchlist(movieId);
      return response.data.isInWatchlist;
    } catch (error) {
      console.error('Error checking watchlist:', error);
      return false;
    }
  }

  // Render movie cards
  renderMovieCards(movies, containerId, showWatchlistButton = true) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    if (!movies || movies.length === 0) {
      container.innerHTML = '<p class="no-results">No movies found</p>';
      return;
    }

    movies.forEach(movie => {
      const movieCard = this.createMovieCard(movie, showWatchlistButton);
      container.appendChild(movieCard);
    });
  }

  // Create a single movie card
  createMovieCard(movie, showWatchlistButton = true) {
    const movieCard = document.createElement('div');
    movieCard.className = 'movie-card';
    movieCard.innerHTML = `
      <div class="movie-poster">
        <img src="${movie.poster_path || 'https://via.placeholder.com/300x450'}" alt="${movie.title}">
        <div class="movie-overlay">
          <button class="view-btn" data-id="${movie.movie_id}"><i class="fas fa-eye"></i></button>
          ${showWatchlistButton ? `<button class="watchlist-btn ${movie.isInWatchlist ? 'added' : ''}" data-id="${movie.movie_id}">
            <i class="fas fa-bookmark"></i>
          </button>` : ''}
          <button class="rate-btn" data-id="${movie.movie_id}" data-title="${movie.title}">
            <i class="fas fa-star"></i>
          </button>
        </div>
      </div>
      <div class="movie-info">
        <h3 class="movie-title">${movie.title}</h3>
        <div class="movie-meta">
          <span>${movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</span>
          <div class="movie-rating">
            <i class="fas fa-star"></i>
            <span>${movie.avgRating || 'N/A'}</span>
          </div>
        </div>
        <p class="movie-description">${movie.overview || 'No description available'}</p>
      </div>
    `;

    // Add event listeners
    const viewBtn = movieCard.querySelector('.view-btn');
    const watchlistBtn = movieCard.querySelector('.watchlist-btn');
    const rateBtn = movieCard.querySelector('.rate-btn');

    viewBtn.addEventListener('click', () => {
      window.location.href = `movie-details.html?id=${movie.movie_id}`;
    });

    if (watchlistBtn) {
      watchlistBtn.addEventListener('click', () => {
        this.toggleWatchlist(movie.movie_id, watchlistBtn);
      });
    }

    rateBtn.addEventListener('click', () => {
      this.openRatingModal(movie.movie_id, movie.title);
    });

    return movieCard;
  }

  // Open rating modal
  openRatingModal(movieId, movieTitle) {
    if (!this.authService.isLoggedIn()) {
      this.notificationService.show('Please login to rate a movie', 'error');
      return;
    }

    const modal = document.getElementById('rating-modal');
    const movieTitleElement = modal.querySelector('.movie-title');
    const submitBtn = document.getElementById('submit-rating-btn');
    const cancelBtn = document.getElementById('cancel-rating-btn');
    const stars = modal.querySelectorAll('.star-rating span');

    // Set movie title
    if (movieTitleElement) {
      movieTitleElement.textContent = movieTitle;
    }

    // Reset stars
    stars.forEach(star => {
      star.classList.remove('active');
    });

    // Handle star clicks
    let selectedRating = 0;
    stars.forEach((star, index) => {
      star.onclick = () => {
        selectedRating = index + 1;
        this.updateStars(selectedRating);
      };
    });

    // Handle submit
    submitBtn.onclick = async () => {
      if (selectedRating === 0) {
        this.notificationService.show('Please select a rating', 'error');
        return;
      }

      try {
        await this.rateMovie(movieId, selectedRating);
        modal.style.display = 'none';
      } catch (error) {
        console.error('Error rating movie:', error);
      }
    };

    // Handle cancel
    cancelBtn.onclick = () => {
      modal.style.display = 'none';
    };

    // Show modal
    modal.style.display = 'block';
  }

  // Update star display
  updateStars(rating) {
    const stars = document.querySelectorAll('.star-rating span');
    stars.forEach((star, index) => {
      if (index < rating) {
        star.classList.add('active');
      } else {
        star.classList.remove('active');
      }
    });
  }
}

// Create a singleton instance
const movieService = new MovieService();

// Export the instance
window.movieService = movieService;